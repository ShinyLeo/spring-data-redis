/**
 * Connection package for <a href="https://github.com/mp911de/lettuce">Lettuce</a> Redis client.
 */
package org.springframework.data.redis.connection.lettuce;

