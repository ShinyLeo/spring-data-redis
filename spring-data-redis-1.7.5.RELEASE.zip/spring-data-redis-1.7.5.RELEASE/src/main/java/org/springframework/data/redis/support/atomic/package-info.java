/**
 * Small toolkit mirroring the {@code java.util.atomic} package in Redis. 
 */
package org.springframework.data.redis.support.atomic;

