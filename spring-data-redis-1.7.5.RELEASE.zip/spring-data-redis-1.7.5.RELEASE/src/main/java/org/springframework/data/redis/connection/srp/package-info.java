/**
 * Connection package for <a href="https://github.com/spullara/redis-protocol">spullara Redis Protocol</a> library.
 * @deprecated since 1.7. Will be removed in subsequent version.
 */
package org.springframework.data.redis.connection.srp;

