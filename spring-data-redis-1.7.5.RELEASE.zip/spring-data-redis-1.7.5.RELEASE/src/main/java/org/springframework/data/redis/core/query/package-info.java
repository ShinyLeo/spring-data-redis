/**
 * Query package for Redis template.
 */
package org.springframework.data.redis.core.query;

