/**
 * Dedicated support package for Redis hashes.
 * 
 * Provides mapping of objects to hashes/maps (and vice versa).
 */
package org.springframework.data.redis.hash;

