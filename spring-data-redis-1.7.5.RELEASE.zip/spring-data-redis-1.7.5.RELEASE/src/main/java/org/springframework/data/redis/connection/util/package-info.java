/**
 * Internal utility package for encoding/decoding Strings to byte[] (using Base64) library.
 */
package org.springframework.data.redis.connection.util;

