/**
 * Classes supporting the Redis packages, such as collection or atomic counters.
 */
package org.springframework.data.redis.support;

