/**
 * Package providing a Redis implementation for Spring <a href="http://docs.spring.io/spring/docs/current/spring-framework-reference/html/cache.html">cache abstraction</a>.
 */
package org.springframework.data.redis.cache;

